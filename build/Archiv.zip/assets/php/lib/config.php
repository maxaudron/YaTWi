<?php

$ts3_ip = '178.238.233.133';
$ts3_queryport = 10011;
$ts3_port = 9987;
// $ts3_user = 'serveradmin';
// $ts3_pass = 'password';

?>
